# mewt-sniper

> Install the latest version of python from the website https://www.python.org/downloads/

Run
> pip install requests colorama "python-socketio[client]" discord.py rgbprint

Then run the start.bat file or if your on mac use the terminal to run it.